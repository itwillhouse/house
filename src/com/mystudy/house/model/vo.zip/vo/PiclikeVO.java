package com.mystudy.house.model.vo;

public class PiclikeVO {
	private String likeNum, pictureIdx, id, regdate;

	public String getLikeNum() {
		return likeNum;
	}

	public void setLikeNum(String likeNum) {
		this.likeNum = likeNum;
	}

	public String getPictureIdx() {
		return pictureIdx;
	}

	public void setPictureIdx(String pictureIdx) {
		this.pictureIdx = pictureIdx;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

}
