package com.mystudy.house.model.vo;

public class KnowcommentVO {
	private String knowcomIdx, knowhowIdx, content, regdate, id, profileImg;
	
	public String getProfileImg() {
		return profileImg;
	}

	public void setProfileImg(String profileImg) {
		this.profileImg = profileImg;
	}

	public String getKnowcomIdx() {
		return knowcomIdx;
	}

	public void setKnowcomIdx(String knowcomIdx) {
		this.knowcomIdx = knowcomIdx;
	}

	public String getKnowhowIdx() {
		return knowhowIdx;
	}

	public void setKnowhowIdx(String knowhowIdx) {
		this.knowhowIdx = knowhowIdx;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
