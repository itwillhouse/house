package com.mystudy.house.model.vo;

public class KnowlikeVO {
	private String likeNum, knowhowIdx, id;

	public String getLikeNum() {
		return likeNum;
	}

	public void setLikeNum(String likeNum) {
		this.likeNum = likeNum;
	}

	public String getKnowhowIdx() {
		return knowhowIdx;
	}

	public void setKnowhowIdx(String knowhowIdx) {
		this.knowhowIdx = knowhowIdx;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
