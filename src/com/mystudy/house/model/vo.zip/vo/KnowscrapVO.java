package com.mystudy.house.model.vo;

public class KnowscrapVO {
	private String scrapNum, knowhowIdx, id;

	public String getScrapNum() {
		return scrapNum;
	}

	public void setScrapNum(String scrapNum) {
		this.scrapNum = scrapNum;
	}

	public String getKnowhowIdx() {
		return knowhowIdx;
	}

	public void setKnowhowIdx(String knowhowIdx) {
		this.knowhowIdx = knowhowIdx;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
