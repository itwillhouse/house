package com.mystudy.house.model.vo;

public class PicscrapVO {
	private String scrapNum, pictureIdx, id;

	public String getScrapNum() {
		return scrapNum;
	}

	public void setScrapNum(String scrapNum) {
		this.scrapNum = scrapNum;
	}

	public String getPictureIdx() {
		return pictureIdx;
	}

	public void setPictureIdx(String pictureIdx) {
		this.pictureIdx = pictureIdx;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
