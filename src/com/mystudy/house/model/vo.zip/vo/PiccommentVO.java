package com.mystudy.house.model.vo;

public class PiccommentVO {
	private String piccomIdx, pictureIdx, content, regdate, id;

	public String getPiccomIdx() {
		return piccomIdx;
	}

	public void setPiccomIdx(String piccomIdx) {
		this.piccomIdx = piccomIdx;
	}

	public String getPictureIdx() {
		return pictureIdx;
	}

	public void setPictureIdx(String pictureIdx) {
		this.pictureIdx = pictureIdx;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		
}
